<?php

namespace App\Http\Controllers;

use App\Models\Guest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use RealRashid\SweetAlert\Facades\Alert;

class GuestController extends Controller
{
    public function register()
    {
        if (session('error_message')) {
            $errors_arr = [];
            foreach (session('error_message')->messages() as $error) {
                array_push($errors_arr, $error[0]);
            }
            $errors_html = collect($errors_arr)->implode('<br>');
            Alert::html('Error', $errors_html, 'error');
        }

        return view('auth/guest-register');
    }

    public function handleRegister(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'full_name' => 'required|string|max:100',
            'email' => 'required|unique:guests,email|email|max:100',
            'password' => 'required|string|max:100',
            'img' => 'nullable|image|mimes:jpg,png'
        ]);

        if ($validator->fails()) {
            $errors = $validator->errors();
            return redirect(route('guest.register'))->withErrorMessage($errors);
        }

        $img_name = null;

        if ($img = $request->file('img')) {
            $img = $request->file('img');
            $ext = $img->getClientOriginalExtension();
            $img_name = 'guest-' . uniqid() . ".$ext";
            $img->move(public_path('uploads/guests-profile-images'), $img_name);
        }

        $guest = Guest::create([
            'full_name' => $request->full_name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'img' => $img_name
        ]);

        if (!Auth::guard('admin')->check()) {
            Auth::guard('guest')->login($guest);
        }

        return redirect(route('home'))->withSuccessMessage('New Guest Registered Successfully');
    }

    public function login()
    {
        if (session('error_message')) {
            $errors_arr = [];
            foreach (session('error_message')->messages() as $error) {
                array_push($errors_arr, $error[0]);
            }
            $errors_html = collect($errors_arr)->implode('<br>');
            Alert::html('Error', $errors_html, 'error');
        }

        return view('auth/guest-login');
    }

    public function handleLogin(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email|max:100',
            'password' => 'required|string|max:100'
        ]);

        if ($validator->fails()) {
            $errors = $validator->errors();
            return redirect(route('guest.login'))->withErrorMessage($errors);
        }

        $is_login = Auth::guard('guest')->attempt([
            'email' => $request->email,
            'password' => $request->password
        ]);

        if (!$is_login) {
            return redirect(route('guest.login'));
        }

        $guest_name = Auth::guard('guest')->user()->full_name;

        return redirect(route('home'))->withSuccessMessage("Welcome $guest_name");
    }

    public function logout()
    {
        Auth::guard('guest')->logout();

        return redirect(route('home'));
    }

    public function profile()
    {
        if (session('success_message')) {
            Alert::success('Success!', session('success_message'));
        }

        $guest_id = Auth::guard('guest')->user()->id;
        $guest = Guest::findOrFail($guest_id);

        return view('guest-profile', compact('guest'));
    }

    public function update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'full_name' => 'required|string|max:100',
            'img' => 'nullable|image|mimes:jpg,png'
        ]);

        if ($validator->fails()) {
            $errors = $validator->errors();
            return redirect(route('guests.profile'))->withErrorMessage($errors);
        }

        $guest_id = Auth::guard('guest')->user()->id;
        $guest = Guest::findOrFail($guest_id);

        $img_name = null;

        if ($request->hasFile('img')) {
            $img = $request->file('img');
            if ($guest->img != null) {
                unlink(public_path('uploads/guests-profile-images/') . $guest->img);
            }
            $ext = $img->getClientOriginalExtension();
            $img_name = 'guest-' . uniqid() . ".$ext";
            $img->move(public_path('uploads/guests-profile-images'), $img_name);
        }

        if ($request->hasFile('img')) {
            $guest->update([
                'full_name' => $request->full_name,
                'img' => $img_name
            ]);
        } else {
            $guest->update([
                'full_name' => $request->full_name
            ]);
        }

        return redirect(route('guests.profile'))->withSuccessMessage("Information Updated Successfully");
    }

    public function delete($id)
    {
        $guest = Guest::findOrFail($id);

        unlink(public_path('uploads/guests-profile-images/') . $guest->img);

        $guest->delete();

        return redirect(route('admin.dashboard'))->withSuccessMessage("Guest Deleted Successfully");
    }
}
