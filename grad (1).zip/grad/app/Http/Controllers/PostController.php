<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class PostController extends Controller
{
    public function publish(Request $request) {
        $validator = Validator::make($request->all(), [
            'content' => 'required|string'
        ]);

        if ($validator->fails()) {
            $errors = $validator->errors();
            return redirect(route('admin.dashboard'))->withErrorMessage($errors);
        }

        $admin_id = Auth::guard('admin')->user()->id;

        Post::create([
            'admin_id' => $admin_id,
            'content' => $request->content
        ]);

        return redirect(route('admin.dashboard'))->withSuccessMessage("Post Published Successfully");
    }

    public function delete($id) {
        $post = Post::findOrFail($id);

        $post->delete();

        return redirect(route('admin.dashboard'))->withSuccessMessage("Post Deleted Successfully");
    }
}
