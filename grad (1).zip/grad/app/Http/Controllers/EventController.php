<?php

namespace App\Http\Controllers;

use App\Models\Event;
use Illuminate\Http\Request;

class EventController extends Controller
{
    public function index() {
        $events = Event::where('status', '=', 'ACTIVE')->paginate(5);

        return view('events', compact('events'));
    }

    public function lectures() {
        $events = $events = Event::where('status', '=', 'ACTIVE')->paginate(5);

        return view('lectures', compact('events'));
    }

    public function delete($id) {
        $event = Event::findOrFail($id);

        $event->delete();

        return redirect(route('admin.dashboard'))->withSuccessMessage("Event Deleted Successfully");
    }
}
