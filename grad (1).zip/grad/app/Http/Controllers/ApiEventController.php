<?php

namespace App\Http\Controllers;

use App\Models\Event;
use Illuminate\Http\Request;

class ApiEventController extends Controller
{
    public function index() {
        $events = Event::where('status', '=', 'ACTIVE')->get();

        return response()->json($events);
    }
}
