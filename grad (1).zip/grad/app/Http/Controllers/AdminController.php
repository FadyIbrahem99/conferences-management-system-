<?php

namespace App\Http\Controllers;

use App\Models\Admin;
use App\Models\Event;
use App\Models\Guest;
use App\Models\Instructor;
use App\Models\Post;
use App\Models\Supervisor;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use RealRashid\SweetAlert\Facades\Alert;

class AdminController extends Controller
{
    public function register()
    {
        if (session('error_message')) {
            $errors_arr = [];
            foreach (session('error_message')->messages() as $error) {
                array_push($errors_arr, $error[0]);
            }
            $errors_html = collect($errors_arr)->implode('<br>');
            Alert::html('Error', $errors_html, 'error');
        }

        return view('auth/admin-register');
    }

    public function handleRegister(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'full_name' => 'required|string|max:100',
            'email' => 'required|unique:admins,email|email|max:100',
            'password' => 'required|string|max:100',
            'img' => 'nullable|image|mimes:jpg,png'
        ]);

        if ($validator->fails()) {
            $errors = $validator->errors();
            return redirect(route('admin.register'))->withErrorMessage($errors);
        }

        $img_name = null;

        if ($img = $request->file('img')) {
            $img = $request->file('img');
            $ext = $img->getClientOriginalExtension();
            $img_name = 'admin-' . uniqid() . ".$ext";
            $img->move(public_path('uploads/admins-profile-images'), $img_name);
        }

        $admin = Admin::create([
            'full_name' => $request->full_name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'img' => $img_name
        ]);

        Auth::guard('admin')->login($admin);

        return redirect(route('home'))->withSuccessMessage('New Admin Registered Successfully');
    }

    public function login()
    {
        if (session('error_message')) {
            $errors_arr = [];
            foreach (session('error_message')->messages() as $error) {
                array_push($errors_arr, $error[0]);
            }
            $errors_html = collect($errors_arr)->implode('<br>');
            Alert::html('Error', $errors_html, 'error');
        }

        return view('auth/admin-login');
    }

    public function handleLogin(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email|max:100',
            'password' => 'required|string|max:100'
        ]);

        if ($validator->fails()) {
            $errors = $validator->errors();
            return redirect(route('admin.login'))->withErrorMessage($errors);
        }

        $is_login = Auth::guard('admin')->attempt([
            'email' => $request->email,
            'password' => $request->password
        ]);

        if (!$is_login) {
            return redirect(route('admin.login'));
        }

        $admin_name = Auth::guard('admin')->user()->full_name;

        return redirect(route('home'))->withSuccessMessage("Welcome $admin_name");
    }

    public function logout()
    {
        Auth::guard('admin')->logout();

        return redirect(route('home'));
    }

    public function dashboard()
    {
        if (session('error_message')) {
            $errors_arr = [];
            foreach (session('error_message')->messages() as $error) {
                array_push($errors_arr, $error[0]);
            }
            $errors_html = collect($errors_arr)->implode('<br>');
            Alert::html('Error', $errors_html, 'error');
        }

        if (session('success_message')) {
            Alert::success('Success!', session('success_message'));
        }

        $posts = Post::paginate(5);
        $all_posts = Post::all();
        $posts_count = count($all_posts);

        $admins = Admin::paginate(5);
        $all_admins = Admin::all();
        $admins_count = count($all_admins);

        $supervisors = Supervisor::paginate(5);
        $all_supervisors = Supervisor::all();
        $supervisors_count = count($all_supervisors);

        $guests = Guest::paginate(5);
        $all_guests = Guest::all();
        $guests_count = count($all_guests);

        $instructors = Instructor::paginate(5);
        $all_instructors = Instructor::all();
        $instructors_count = count($all_instructors);

        $events = Event::where('status', '=', 'ACTIVE')->paginate(5);
        $all_events = Event::where('status', '=', 'ACTIVE')->get();
        $events_count = count($all_events);

        $data = [
            'posts' => $posts,
            'posts_count' => $posts_count,
            'admins' => $admins,
            'admins_count' => $admins_count,
            'supervisors' => $supervisors,
            'supervisors_count' => $supervisors_count,
            'guests' => $guests,
            'guests_count' => $guests_count,
            'instructors' => $instructors,
            'instructors_count' => $instructors_count,
            'events' => $events,
            'events_count' => $events_count,
        ];

        return view('admin-dashboard/admin-dashboard', compact('data'));
    }

    public function profile()
    {
        if (session('success_message')) {
            Alert::success('Success!', session('success_message'));
        }

        $admin_id = Auth::guard('admin')->user()->id;
        $admin = Admin::findOrFail($admin_id);

        return view('admin-profile', compact('admin'));
    }

    public function update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'full_name' => 'required|string|max:100',
            'img' => 'nullable|image|mimes:jpg,png'
        ]);

        if ($validator->fails()) {
            $errors = $validator->errors();
            return redirect(route('admins.profile'))->withErrorMessage($errors);
        }

        $admin_id = Auth::guard('admin')->user()->id;
        $admin = Admin::findOrFail($admin_id);

        $img_name = null;

        if ($request->hasFile('img')) {
            $img = $request->file('img');
            if ($admin->img != null) {
                unlink(public_path('uploads/admins-profile-images/') . $admin->img);
            }
            $ext = $img->getClientOriginalExtension();
            $img_name = 'admin-' . uniqid() . ".$ext";
            $img->move(public_path('uploads/admins-profile-images'), $img_name);
        }

        if ($request->hasFile('img')) {
            $admin->update([
                'full_name' => $request->full_name,
                'img' => $img_name
            ]);
        } else {
            $admin->update([
                'full_name' => $request->full_name
            ]);
        }

        return redirect(route('admins.profile'))->withSuccessMessage("Information Updated Successfully");
    }

    public function delete($id)
    {
        $admin = Admin::findOrFail($id);

        unlink(public_path('uploads/admins-profile-images/') . $admin->img);

        $admin->delete();

        return redirect(route('admin.dashboard'))->withSuccessMessage("Admin Deleted Successfully");
    }
}
