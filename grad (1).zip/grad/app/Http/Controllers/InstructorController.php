<?php

namespace App\Http\Controllers;

use App\Models\Event;
use App\Models\Instructor;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use RealRashid\SweetAlert\Facades\Alert;

class InstructorController extends Controller
{
    public function register()
    {
        if (session('error_message')) {
            $errors_arr = [];
            foreach (session('error_message')->messages() as $error) {
                array_push($errors_arr, $error[0]);
            }
            $errors_html = collect($errors_arr)->implode('<br>');
            Alert::html('Error', $errors_html, 'error');
        }

        return view('auth/instructor-register');
    }

    public function handleRegister(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'full_name' => 'required|string|max:100',
            'email' => 'required|unique:instructors,email|email|max:100',
            'password' => 'required|string|max:100',
            'specialization' => 'required|string|max:100',
            'title' => 'required|string|max:100',
            'about' => 'required|string',
            'students' => 'required',
            'reviews' => 'required|string',
            'twitter' => 'nullable|string',
            'linkedin' => 'nullable|string',
            'img' => 'nullable|image|mimes:jpg,png'
        ]);

        if ($validator->fails()) {
            $errors = $validator->errors();
            return redirect(route('instructor.register'))->withErrorMessage($errors);
        }

        $img_name = null;

        if ($img = $request->file('img')) {
            $img = $request->file('img');
            $ext = $img->getClientOriginalExtension();
            $img_name = 'instructor-' . uniqid() . ".$ext";
            $img->move(public_path('uploads/instructors-profile-images'), $img_name);
        }

        $instructor = Instructor::create([
            'full_name' => $request->full_name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'specialization' => $request->specialization,
            'title' => $request->title,
            'about' => $request->about,
            'students' => $request->students,
            'reviews' => $request->reviews,
            'twitter' => $request->twitter,
            'linkedin' => $request->linkedin,
            'img' => $img_name
        ]);

        if (!Auth::guard('admin')->check()) {
            Auth::guard('instructor')->login($instructor);
        }

        return redirect(route('home'))->withSuccessMessage('New Instructor Registered Successfully');
    }

    public function login()
    {
        if (session('error_message')) {
            $errors_arr = [];
            foreach (session('error_message')->messages() as $error) {
                array_push($errors_arr, $error[0]);
            }
            $errors_html = collect($errors_arr)->implode('<br>');
            Alert::html('Error', $errors_html, 'error');
        }

        return view('auth/instructor-login');
    }

    public function handleLogin(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email|max:100',
            'password' => 'required|string|max:100'
        ]);

        if ($validator->fails()) {
            $errors = $validator->errors();
            return redirect(route('instructor.login'))->withErrorMessage($errors);
        }

        $is_login = Auth::guard('instructor')->attempt([
            'email' => $request->email,
            'password' => $request->password
        ]);

        if (!$is_login) {
            return redirect(route('instructor.login'));
        }

        $instructor_name = Auth::guard('instructor')->user()->full_name;

        return redirect(route('home'))->withSuccessMessage("Welcome $instructor_name");
    }

    public function logout()
    {
        Auth::guard('instructor')->logout();

        return redirect(route('home'));
    }

    public function instructors()
    {
        $instructors = Instructor::paginate(2);

        return view('instructors', compact('instructors'));
    }

    public function instructorView($id)
    {
        $instructor = Instructor::findOrFail($id);

        return view('instructor-view', compact('instructor'));
    }

    public function profile()
    {
        if (session('success_message')) {
            Alert::success('Success!', session('success_message'));
        }

        $instructor_id = Auth::guard('instructor')->user()->id;
        $instructor = Instructor::findOrFail($instructor_id);

        return view('instructor-profile', compact('instructor'));
    }

    public function update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'full_name' => 'required|string|max:100',
            'specialization' => 'required|string|max:100',
            'title' => 'required|string|max:100',
            'about' => 'required|string',
            'students' => 'required',
            'reviews' => 'required',
            'twitter' => 'required',
            'linkedin' => 'required',
            'img' => 'nullable|image|mimes:jpg,png'
        ]);

        if ($validator->fails()) {
            $errors = $validator->errors();
            return redirect(route('instructors.profile'))->withErrorMessage($errors);
        }

        $instructor_id = Auth::guard('instructor')->user()->id;
        $instructor = Instructor::findOrFail($instructor_id);

        $img_name = null;

        if ($request->hasFile('img')) {
            $img = $request->file('img');
            if ($instructor->img != null) {
                unlink(public_path('uploads/instructors-profile-images/') . $instructor->img);
            }
            $ext = $img->getClientOriginalExtension();
            $img_name = 'instructor-' . uniqid() . ".$ext";
            $img->move(public_path('uploads/instructors-profile-images'), $img_name);
        }

        if ($request->hasFile('img')) {
            $instructor->update([
                'full_name' => $request->full_name,
                'specialization' => $request->specialization,
                'title' => $request->title,
                'about' => $request->about,
                'students' => $request->students,
                'reviews' => $request->reviews,
                'twitter' => $request->twitter,
                'linkedin' => $request->linkedin,
                'img' => $img_name
            ]);
        } else {
            $instructor->update([
                'full_name' => $request->full_name,
                'specialization' => $request->specialization,
                'title' => $request->title,
                'about' => $request->about,
                'students' => $request->students,
                'reviews' => $request->reviews,
                'twitter' => $request->twitter,
                'linkedin' => $request->linkedin
            ]);
        }

        return redirect(route('instructors.profile'))->withSuccessMessage("Information Updated Successfully");
    }

    public function request()
    {
        if (session('error_message')) {
            $errors_arr = [];
            foreach (session('error_message')->messages() as $error) {
                array_push($errors_arr, $error[0]);
            }
            $errors_html = collect($errors_arr)->implode('<br>');
            Alert::html('Error', $errors_html, 'error');
        }

        return view('instructor-request');
    }

    public function handleRequest(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'title' => 'required|string|max:100',
            'subject' => 'required|string|max:100',
            'desc' => 'required|string',
            'start_date' => 'required',
            'end_date' => 'required',
            'hall' => 'required|string|max:100',
            'video' => 'required'
        ]);

        if ($validator->fails()) {
            $errors = $validator->errors();
            return redirect(route('instructor.request'))->withErrorMessage($errors);
        }

        $instructor_id = Auth::guard('instructor')->user()->id;

        $event = Event::create([
            'instructor_id' => $instructor_id,
            'title' => $request->title,
            'subject' => $request->subject,
            'desc' => $request->desc,
            'start_date' => $request->start_date,
            'end_date' => $request->end_date,
            'hall' => $request->hall,
            'video' => $request->video
        ]);

        return redirect(route('instructors.profile'))->withSuccessMessage('New Event Requested Successfully');
    }

    public function delete($id)
    {
        $instructor = Instructor::findOrFail($id);

        unlink(public_path('uploads/instructors-profile-images/') . $instructor->img);

        $instructor->delete();

        return redirect(route('admin.dashboard'))->withSuccessMessage("Instructor Deleted Successfully");
    }
}
