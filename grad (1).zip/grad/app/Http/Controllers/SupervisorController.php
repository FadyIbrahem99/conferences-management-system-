<?php

namespace App\Http\Controllers;

use App\Models\Event;
use App\Models\Supervisor;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use RealRashid\SweetAlert\Facades\Alert;

class SupervisorController extends Controller
{
    public function register()
    {
        if (session('error_message')) {
            $errors_arr = [];
            foreach (session('error_message')->messages() as $error) {
                array_push($errors_arr, $error[0]);
            }
            $errors_html = collect($errors_arr)->implode('<br>');
            Alert::html('Error', $errors_html, 'error');
        }

        return view('auth/supervisor-register');
    }

    public function handleRegister(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'full_name' => 'required|string|max:100',
            'email' => 'required|unique:supervisors,email|email|max:100',
            'password' => 'required|string|max:100',
            'img' => 'nullable|image|mimes:jpg,png'
        ]);

        if ($validator->fails()) {
            $errors = $validator->errors();
            return redirect(route('supervisor.register'))->withErrorMessage($errors);
        }

        $img_name = null;

        if ($img = $request->file('img')) {
            $img = $request->file('img');
            $ext = $img->getClientOriginalExtension();
            $img_name = 'supervisor-' . uniqid() . ".$ext";
            $img->move(public_path('uploads/supervisors-profile-images'), $img_name);
        }

        $supervisor = Supervisor::create([
            'full_name' => $request->full_name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'img' => $img_name
        ]);

        if (!Auth::guard('admin')->check()) {
            Auth::guard('supervisor')->login($supervisor);
        }

        return redirect(route('home'))->withSuccessMessage('New Supervisor Registered Successfully');
    }

    public function login()
    {
        if (session('error_message')) {
            $errors_arr = [];
            foreach (session('error_message')->messages() as $error) {
                array_push($errors_arr, $error[0]);
            }
            $errors_html = collect($errors_arr)->implode('<br>');
            Alert::html('Error', $errors_html, 'error');
        }

        return view('auth/supervisor-login');
    }

    public function handleLogin(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email|max:100',
            'password' => 'required|string|max:100'
        ]);

        if ($validator->fails()) {
            $errors = $validator->errors();
            return redirect(route('supervisor.login'))->withErrorMessage($errors);
        }

        $is_login = Auth::guard('supervisor')->attempt([
            'email' => $request->email,
            'password' => $request->password
        ]);

        if (!$is_login) {
            return redirect(route('supervisor.login'));
        }

        $supervisor_name = Auth::guard('supervisor')->user()->full_name;

        return redirect(route('home'))->withSuccessMessage("Welcome $supervisor_name");
    }

    public function logout()
    {
        Auth::guard('supervisor')->logout();

        return redirect(route('home'));
    }

    public function dashboard()
    {
        if (session('success_message')) {
            Alert::success('Success!', session('success_message'));
        }

        $events = Event::where('status', '=', 'NOT_ACTIVE')->paginate(5);
        return view('supervisor-dashboard/supervisor-dashboard', compact('events'));
    }

    public function profile()
    {
        if (session('success_message')) {
            Alert::success('Success!', session('success_message'));
        }

        $supervisor_id = Auth::guard('supervisor')->user()->id;
        $supervisor = Supervisor::findOrFail($supervisor_id);

        return view('supervisor-profile', compact('supervisor'));
    }

    public function update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'full_name' => 'required|string|max:100',
            'img' => 'nullable|image|mimes:jpg,png'
        ]);

        if ($validator->fails()) {
            $errors = $validator->errors();
            return redirect(route('supervisors.profile'))->withErrorMessage($errors);
        }

        $supervisor_id = Auth::guard('supervisor')->user()->id;
        $supervisor = Supervisor::findOrFail($supervisor_id);

        $img_name = null;

        if ($request->hasFile('img')) {
            $img = $request->file('img');
            if ($supervisor->img != null) {
                unlink(public_path('uploads/supervisors-profile-images/') . $supervisor->img);
            }
            $ext = $img->getClientOriginalExtension();
            $img_name = 'supervisor-' . uniqid() . ".$ext";
            $img->move(public_path('uploads/supervisors-profile-images'), $img_name);
        }

        if ($request->hasFile('img')) {
            $supervisor->update([
                'full_name' => $request->full_name,
                'img' => $img_name
            ]);
        } else {
            $supervisor->update([
                'full_name' => $request->full_name
            ]);
        }



        return redirect(route('supervisors.profile'))->withSuccessMessage("Information Updated Successfully");
    }

    public function accept($id)
    {
        $event = Event::findOrFail($id);
        $event->update([
            'status' => 'ACTIVE'
        ]);

        return redirect(route('supervisor.dashboard'))->withSuccessMessage("Event Accepted Successfully");
    }

    public function reject($id)
    {
        $event = Event::findOrFail($id);
        $event->delete();

        return redirect(route('supervisor.dashboard'))->withSuccessMessage("Event Rejected Successfully");
    }

    public function delete($id)
    {
        $supervisor = Supervisor::findOrFail($id);

        unlink(public_path('uploads/supervisors-profile-images/') . $supervisor->img);

        $supervisor->delete();

        return redirect(route('admin.dashboard'))->withSuccessMessage("Supervisor Deleted Successfully");
    }
}
