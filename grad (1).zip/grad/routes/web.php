<?php

use App\Models\Event;
use App\Models\Post;
use Illuminate\Support\Facades\Route;
use RealRashid\SweetAlert\Facades\Alert;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    if (session('success_message')) {
        Alert::success('Success!', session('success_message'));
    }

    $posts = Post::paginate(10);
    $events = Event::where('status', '=', 'ACTIVE')->limit(3)->get();

    $data = [
        'posts' => $posts,
        'events' => $events
    ];

    return view('home', compact('data'));
})->name('home');

Route::middleware('is.admin')->group(function () {
    Route::get('/admin/register', 'App\Http\Controllers\AdminController@register')->name('admin.register');
    Route::post('/admin/register/handle', 'App\Http\Controllers\AdminController@handleRegister')->name('admin.register.handle');
    Route::get('/admin/logout', 'App\Http\Controllers\AdminController@logout')->name('admin.logout');
    Route::get('/admin/dashboard', 'App\Http\Controllers\AdminController@dashboard')->name('admin.dashboard');
    Route::get('/admin/delete/{id}', 'App\Http\Controllers\AdminController@delete')->name('admins.delete');
    Route::get('/admin/profile', 'App\Http\Controllers\AdminController@profile')->name('admins.profile');
    Route::post('/admin/update', 'App\Http\Controllers\AdminController@update')->name('admins.update');

    Route::get('/supervisor/register', 'App\Http\Controllers\SupervisorController@register')->name('supervisor.register');
    Route::post('/supervisor/register/handle', 'App\Http\Controllers\SupervisorController@handleRegister')->name('supervisor.register.handle');
    Route::get('/supervisor/delete/{id}', 'App\Http\Controllers\SupervisorController@delete')->name('supervisors.delete');

    Route::get('/guest/delete/{id}', 'App\Http\Controllers\GuestController@delete')->name('guests.delete');

    Route::get('/instructor/delete/{id}', 'App\Http\Controllers\InstructorController@delete')->name('instructors.delete');

    Route::post('/posts/publish', 'App\Http\Controllers\PostController@publish')->name('posts.publish');
    Route::get('/posts/delete/{id}', 'App\Http\Controllers\PostController@delete')->name('posts.delete');

    Route::get('/events/delete/{id}', 'App\Http\Controllers\EventController@delete')->name('events.delete');
});

Route::middleware('is.supervisor')->group(function () {
    Route::get('/supervisor/dashboard', 'App\Http\Controllers\SupervisorController@dashboard')->name('supervisor.dashboard');
    Route::get('/supervisor/logout', 'App\Http\Controllers\SupervisorController@logout')->name('supervisor.logout');
    Route::get('/supervisor/profile', 'App\Http\Controllers\SupervisorController@profile')->name('supervisors.profile');
    Route::post('/supervisor/update', 'App\Http\Controllers\SupervisorController@update')->name('supervisors.update');
    Route::get('/event/accept/{id}', 'App\Http\Controllers\SupervisorController@accept')->name('event.accept');
    Route::get('/event/reject/{id}', 'App\Http\Controllers\SupervisorController@reject')->name('event.reject');
});

Route::middleware('is.guest')->group(function () {
    Route::get('/guest/logout', 'App\Http\Controllers\GuestController@logout')->name('guest.logout');
    Route::get('/guest/profile', 'App\Http\Controllers\GuestController@profile')->name('guests.profile');
    Route::post('/guest/update', 'App\Http\Controllers\GuestController@update')->name('guests.update');
});

Route::middleware('is.instructor')->group(function () {
    Route::get('/instructor/logout', 'App\Http\Controllers\InstructorController@logout')->name('instructor.logout');
    Route::get('/instructor/profile', 'App\Http\Controllers\InstructorController@profile')->name('instructors.profile');
    Route::post('/instructor/update', 'App\Http\Controllers\InstructorController@update')->name('instructors.update');
    Route::get('/instructor/request', 'App\Http\Controllers\InstructorController@request')->name('instructor.request');
    Route::post('/instructor/request/handle', 'App\Http\Controllers\InstructorController@handleRequest')->name('instructor.request.handle');
});

Route::get('/admin/login', 'App\Http\Controllers\AdminController@login')->name('admin.login');
Route::post('/admin/login/handle', 'App\Http\Controllers\AdminController@handleLogin')->name('admin.login.handle');

Route::get('/login', function () {
    return view('auth/login');
})->name('login');

Route::get('/register', function () {
    return view('auth/register');
})->name('register');

Route::get('/supervisor/login', 'App\Http\Controllers\SupervisorController@login')->name('supervisor.login');
Route::post('/supervisor/login/handle', 'App\Http\Controllers\SupervisorController@handleLogin')->name('supervisor.login.handle');


Route::get('/guest/register', 'App\Http\Controllers\GuestController@register')->name('guest.register');
Route::post('/guest/register/handle', 'App\Http\Controllers\GuestController@handleRegister')->name('guest.register.handle');
Route::get('/guest/login', 'App\Http\Controllers\GuestController@login')->name('guest.login');
Route::post('/guest/login/handle', 'App\Http\Controllers\GuestController@handleLogin')->name('guest.login.handle');

Route::get('/instructor/register', 'App\Http\Controllers\InstructorController@register')->name('instructor.register');
Route::post('/instructor/register/handle', 'App\Http\Controllers\InstructorController@handleRegister')->name('instructor.register.handle');
Route::get('/instructor/login', 'App\Http\Controllers\InstructorController@login')->name('instructor.login');
Route::post('/instructor/login/handle', 'App\Http\Controllers\InstructorController@handleLogin')->name('instructor.login.handle');
Route::get('/instructors', 'App\Http\Controllers\InstructorController@instructors')->name('instructors');
Route::get('/instructor/view/{id?}', 'App\Http\Controllers\InstructorController@instructorView')->name('instructor.view');

Route::get('/about', function () {
    return view('about');
})->name('about');

Route::get('/events', 'App\Http\Controllers\EventController@index')->name('events');
Route::get('/lectures', 'App\Http\Controllers\EventController@lectures')->name('lectures');
