@extends('layout')

@section('title')
    Request an Event
@endsection

@section('styles')
    <link rel="stylesheet" href="{{ asset('css/instructor-request.css') }}">
@endsection

@section('content')
    <section class="py-5">
        <div class="container">
            <h3 class="fw-bold text-center">Request New Event</h3>
            <p class="text-center text-muted">Please Fill The Event information Below</p>
            <form action="{{ route('instructor.request.handle') }}" method="POST" enctype="multipart/form-data"
                class="py-3">
                @csrf
                <input type="text" name="title" class="form-control my-3" placeholder="Event Title">
                <input type="text" name="subject" class="form-control my-3" placeholder="Event Subject">
                <input type="text" name="desc" class="form-control my-3" placeholder="Event Description">
                <label class="pt-2">Start Time</label>
                <input type="datetime-local" name="start_date" class="form-control mb-3">
                <label>End Time</label>
                <input type="datetime-local" name="end_date" class="form-control mb-3">
                <input type="text" name="hall" class="form-control my-3" placeholder="Event Hall">
                <input type="text" name="video" class="form-control my-3" placeholder="Youtube URL">
                <div class="text-center">
                    <input type="submit" value="Request" class="btn-mine px-4 py-2">
                </div>
            </form>
        </div>
    </section>
@endsection
