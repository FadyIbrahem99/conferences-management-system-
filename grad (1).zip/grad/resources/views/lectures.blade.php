@extends('layout')

@section('title')
    Lectures
@endsection

@section('styles')
    <link rel="stylesheet" href="{{ asset('css/lectures.css') }}">
@endsection

@section('content')
    <header class="py-5">
        <div class="container">
            <div class="row justify-content-center">
                @foreach ($events as $event)
                    @if (Carbon\Carbon::now() > $event->end_date)
                        <div class="col-md-6 p-4 my-4">
                            <h4 class="text-center fw-bold text-mine">{{ $event->title }}</h4>
                            <h6 class="text-center fw-bold text-muted">{{ $event->instructor->full_name }}</h6>
                            <iframe class="w-100" height="315" src="{{ $event->video }}"
                                title="YouTube video player" frameborder="0"
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                allowfullscreen></iframe>
                        </div>
                    @endif
                @endforeach
            </div>
        </div>
    </header>
@endsection
