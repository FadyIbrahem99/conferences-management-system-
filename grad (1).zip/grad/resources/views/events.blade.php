@extends('layout')

@section('title')
    Events
@endsection

@section('styles')
    <link rel="stylesheet" href="{{ asset('css/events.css') }}">
@endsection

@section('content')
    <header>
        <div class="container">
            @foreach ($events as $event)
                <div class="row align-items-center fst-italic py-2">
                    <div class="col-2 event-date text-center bg-beig d-inline-block">
                        <h3 class="fw-bold">{{ \Carbon\Carbon::parse($event->start_date)->format('d') }}</h3>
                        <h5>{{ substr(\Carbon\Carbon::parse($event->start_date)->format('F'), 0, 3) }}</h5>
                    </div>
                    <div class="col-10 event-text p-4">
                        <h6 class="fw-bold">{{ $event->title }}</h6>
                        <h6>{{ $event->subject }} | {{ \Carbon\Carbon::parse($event->start_date)->format('g:i A') }} : {{ \Carbon\Carbon::parse($event->end_date)->format('g:i A') }}</h6>
                        <h6>{{ $event->instructor->full_name }}</h6>
                    </div>
                </div>
            @endforeach
        </div>
    </header>

    <section class="py-5">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-6 col-md-3 p-5 text-center">
                    <img src="{{ asset('images/events-1.png') }}" class="w-100">
                </div>
                <div class="col-6 col-md-3 p-5 text-center">
                    <img src="{{ asset('images/events-2.png') }}" class="w-100">
                </div>
                <div class="col-6 col-md-3 p-5 text-center">
                    <img src="{{ asset('images/events-3.png') }}" class="w-100">
                </div>
                <div class="col-6 col-md-3 p-5 text-center">
                    <img src="{{ asset('images/events-4.png') }}" class="w-100">
                </div>
            </div>
        </div>
    </section>
@endsection
