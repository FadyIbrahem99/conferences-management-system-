@extends('admin-dashboard/admin-dashboard-layout')

@section('title')
    Admin Dashboard
@endsection

@section('styles')
    <link rel="stylesheet" href="{{ asset('css/admin-dashboard/admin-dashboard.css') }}">
@endsection

@section('content')
    <header></header>
    <section class="featured-events py-5 px-4">
        <div class="container-fluid">
            <h2 class="fw-bold text-mine">Dashboard</h2>
            <div class="row">
                <div class="col-md-4 my-4">
                    <div class="insights-panel admin-panel p-4">
                        <h5 class="fw-bold d-flex align-items-center">
                            Insights
                            <div class="panel-icon">
                                <i class="fa-solid fa-chart-line"></i>
                            </div>
                        </h5>
                        <div class="row">
                            <div class="col-md-6 p-3">
                                <div class="admin-panel-div p-3 text-center">
                                    <div class="panel-icon mx-auto">
                                        <i class="fa-solid fa-calendar"></i>
                                    </div>
                                    <h6 class="fw-bold py-3">Events</h6>
                                    <h5 class="fw-bold">{{ $data['events_count'] }}</h5>
                                </div>
                            </div>
                            <!--<div class="col-md-6 p-3">
                                <div class="admin-panel-div p-3 text-center">
                                    <div class="panel-icon mx-auto">
                                        <i class="fa-solid fa-people-group"></i>
                                    </div>
                                    <h6 class="fw-bold py-3">People Reached</h6>
                                    <h5 class="fw-bold">29</h5>
                                </div>
                            </div>-->
                            <div class="col-md-6 p-3">
                                <div class="admin-panel-div p-3 text-center">
                                    <div class="panel-icon mx-auto">
                                        <i class="fa-solid fa-file-lines"></i>
                                    </div>
                                    <h6 class="fw-bold py-3">Posts</h6>
                                    <h5 class="fw-bold">{{ $data['posts_count'] }}</h5>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 p-3">
                                <div class="admin-panel-div p-3 text-center">
                                    <div class="panel-icon mx-auto">
                                        <i class="fa-solid fa-user-gear"></i>
                                    </div>
                                    <h6 class="fw-bold py-3">Admins</h6>
                                    <h5 class="fw-bold">{{ $data['admins_count'] }}</h5>
                                </div>
                            </div>
                            <div class="col-md-6 p-3">
                                <div class="admin-panel-div p-3 text-center">
                                    <div class="panel-icon mx-auto">
                                        <i class="fa-solid fa-headset"></i>
                                    </div>
                                    <h6 class="fw-bold py-3">Supervisors</h6>
                                    <h5 class="fw-bold">{{ $data['supervisors_count'] }}</h5>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 p-3">
                                <div class="admin-panel-div p-3 text-center">
                                    <div class="panel-icon mx-auto">
                                        <i class="fa-solid fa-graduation-cap"></i>
                                    </div>
                                    <h6 class="fw-bold py-3">Guests</h6>
                                    <h5 class="fw-bold">{{ $data['guests_count'] }}</h5>
                                </div>
                            </div>
                            <div class="col-md-6 p-3">
                                <div class="admin-panel-div p-3 text-center">
                                    <div class="panel-icon mx-auto">
                                        <i class="fa-solid fa-person-chalkboard"></i>
                                    </div>
                                    <h6 class="fw-bold py-3">Instructors</h6>
                                    <h5 class="fw-bold">{{ $data['instructors_count'] }}</h5>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <!--<div class="col-md-6 p-3">
                                <div class="admin-panel-div p-3 text-center">
                                    <div class="panel-icon mx-auto">
                                        <i class="fa-solid fa-video"></i>
                                    </div>
                                    <h6 class="fw-bold py-3">Lectures</h6>
                                    <h5 class="fw-bold">36</h5>
                                </div>
                            </div>-->
                        </div>
                        <div class="row">
                            <div class="col-12 p-3">
                                <div class="admin-panel-div p-3 text-start">
                                    <div class="d-flex justify-content-between">
                                        <h6 class="fw-bold d-flex align-items-center">
                                            Admins
                                            <div class="panel-icon">
                                                <i class="fa-solid fa-user-gear"></i>
                                            </div>
                                        </h6>
                                        <a href="{{ route('admin.register') }}" class="text-decoration-none">
                                            <div class="panel-icon">
                                                <i class="fa-solid fa-plus"></i>
                                            </div>
                                        </a>
                                    </div>
                                    @foreach ($data['admins'] as $admin)
                                        <div class="d-flex py-4 justify-content-between align-items-center">
                                            <h6 class="fw-bold">{{ $admin->full_name }}</h6>
                                            <div>
                                                <a href="{{ route('admins.delete', $admin->id) }}"
                                                    class="text-decoration-none text-light p-2">
                                                    <i class="fa-solid fa-trash"></i>
                                                </a>
                                            </div>
                                        </div>
                                    @endforeach
                                    <div class="d-flex justify-content-center">
                                        {!! $data['admins']->links() !!}
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12 p-3">
                                <div class="admin-panel-div p-3 text-start">
                                    <div class="d-flex justify-content-between">
                                        <h6 class="fw-bold d-flex align-items-center">
                                            Supervisors
                                            <div class="panel-icon">
                                                <i class="fa-solid fa-headset"></i>
                                            </div>
                                        </h6>
                                        <a href="{{ route('supervisor.register') }}" class="text-decoration-none">
                                            <div class="panel-icon">
                                                <i class="fa-solid fa-plus"></i>
                                            </div>
                                        </a>
                                    </div>
                                    @foreach ($data['supervisors'] as $supervisor)
                                        <div class="d-flex py-4 justify-content-between align-items-center">
                                            <h6 class="fw-bold">{{ $supervisor->full_name }}</h6>
                                            <div>
                                                <a href="{{ route('supervisors.delete', $supervisor->id) }}"
                                                    class="text-decoration-none text-light p-2">
                                                    <i class="fa-solid fa-trash"></i>
                                                </a>
                                            </div>
                                        </div>
                                    @endforeach
                                    <div class="d-flex justify-content-center">
                                        {!! $data['supervisors']->links() !!}
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12 p-3">
                                <div class="admin-panel-div p-3 text-start">
                                    <div class="d-flex justify-content-between">
                                        <h6 class="fw-bold d-flex align-items-center">
                                            Guests
                                            <div class="panel-icon">
                                                <i class="fa-solid fa-graduation-cap"></i>
                                            </div>
                                        </h6>
                                        <a href="{{ route('guest.register') }}" class="text-decoration-none">
                                            <div class="panel-icon">
                                                <i class="fa-solid fa-plus"></i>
                                            </div>
                                        </a>
                                    </div>
                                    @foreach ($data['guests'] as $guest)
                                        <div class="d-flex py-4 justify-content-between align-items-center">
                                            <h6 class="fw-bold">{{ $guest->full_name }}</h6>
                                            <div>
                                                <a href="{{ route('guests.delete', $guest->id) }}"
                                                    class="text-decoration-none text-light p-2">
                                                    <i class="fa-solid fa-trash"></i>
                                                </a>
                                            </div>
                                        </div>
                                    @endforeach
                                    <div class="d-flex justify-content-center">
                                        {!! $data['guests']->links() !!}
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12 p-3">
                                <div class="admin-panel-div p-3 text-start">
                                    <div class="d-flex justify-content-between">
                                        <h6 class="fw-bold d-flex align-items-center">
                                            Instructors
                                            <div class="panel-icon">
                                                <i class="fa-solid fa-person-chalkboard"></i>
                                            </div>
                                        </h6>
                                        <a href="{{ route('instructor.register') }}" class="text-decoration-none">
                                            <div class="panel-icon">
                                                <i class="fa-solid fa-plus"></i>
                                            </div>
                                        </a>
                                    </div>
                                    @foreach ($data['instructors'] as $instructor)
                                        <div class="d-flex py-4 justify-content-between align-items-center">
                                            <h6 class="fw-bold">{{ $instructor->full_name }}</h6>
                                            <div>
                                                <a href="{{ route('instructors.delete', $instructor->id) }}"
                                                    class="text-decoration-none text-light p-2">
                                                    <i class="fa-solid fa-trash"></i>
                                                </a>
                                            </div>
                                        </div>
                                    @endforeach
                                    <div class="d-flex justify-content-center">
                                        {!! $data['instructors']->links() !!}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-8 my-4">
                    <div class="create-post-panel admin-panel p-4">
                        <h5 class="fw-bold d-flex align-items-center pb-3">
                            Create Post
                            <div class="panel-icon">
                                <i class="fa-solid fa-plus"></i>
                            </div>
                        </h5>
                        <form action="{{ route('posts.publish') }}" method="POST">
                            @csrf
                            <label class="pb-3">Post Content</label>
                            <textarea name="content" class="form-control bg-transparent text-light" cols="30" rows="10"></textarea>
                            <div class="text-center pt-4">
                                <input type="submit" value="Publish"
                                    class="text-decoration-none border-0 panel-btn py-2 px-4 rounded-pill">
                            </div>
                        </form>
                    </div>
                    <div class="posts-panel admin-panel p-4 my-4">
                        <h5 class="fw-bold d-flex align-items-center pb-3">
                            Posts
                            <div class="panel-icon">
                                <i class="fa-solid fa-file-lines"></i>
                            </div>
                        </h5>
                        @foreach ($data['posts'] as $post)
                            <div class="post admin-panel-div p-3 text-center my-4">
                                <div class="row pb-3">
                                    <div class="col-6 text-start">
                                        <h6 class="fw-bold">Published by {{ $post->admin->full_name }}
                                            {{ \Carbon\Carbon::parse($post->created_at)->format('d/m/Y g:i A') }}</h6>
                                    </div>
                                    <div class="col-6 text-end">
                                        <a href="{{ route('posts.delete', $post->id) }}"
                                            class="text-decoration-none text-light p-2">
                                            <i class="fa-solid fa-trash"></i>
                                        </a>
                                    </div>
                                </div>
                                <div class="post-content py-4">
                                    <p>
                                        {{ $post->content }}
                                    </p>
                                </div>
                                <!--<div class="row pt-3">
                                    <div class="col-6 text-center">
                                        <h6 class="fw-bold">People Reached: {{ $post->views }}</h6>
                                    </div>
                                    <div class="col-6 text-center">
                                        <h6 class="fw-bold">Likes: {{ $post->likes }}</h6>
                                    </div>
                                </div>-->
                            </div>
                        @endforeach
                        <div class="d-flex justify-content-center">
                            {!! $data['posts']->links() !!}
                        </div>
                    </div>
                    <div class="posts-panel admin-panel p-4 my-4">
                        <h5 class="fw-bold d-flex align-items-center pb-3">
                            Events
                            <div class="panel-icon">
                                <i class="fa-solid fa-calendar"></i>
                            </div>
                        </h5>
                        @foreach ($data['events'] as $event)
                            <div class="post admin-panel-div p-3 text-center my-4">
                                <div class="row pb-3 text-end">
                                    <a href="{{ route('events.delete', $event->id) }}"
                                        class="text-decoration-none text-light p-2">
                                        <i class="fa-solid fa-trash"></i>
                                    </a>
                                </div>
                                <div class="post-content py-4">
                                    <h5 class="fw-bold">{{ $event->title }}</h5>
                                    <h4 class="fw-bold">{{ $event->subject }}</h4>
                                    <h6 class="fw-bold">
                                        {{ \Carbon\Carbon::parse($event->start_date)->format('d/m/Y g:i A') }}</h6>
                                    <p>
                                        {{ $event->desc }}
                                    </p>
                                    <h6 class="fw-bold">{{ $event->hall }}</h6>
                                </div>
                            </div>
                        @endforeach
                        <div class="d-flex justify-content-center">
                            {!! $data['events']->links() !!}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
