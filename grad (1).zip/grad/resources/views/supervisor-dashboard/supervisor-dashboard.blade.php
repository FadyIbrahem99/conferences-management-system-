@extends('supervisor-dashboard/supervisor-dashboard-layout')

@section('title')
    Supervisor Dashboard
@endsection

@section('styles')
    <link rel="stylesheet" href="{{ asset('css/supervisor-dashboard/supervisor-dashboard.css') }}">
@endsection

@section('content')
    <header></header>
    <section class="featured-events py-5 px-4">
        <div class="container-fluid">
            <h2 class="fw-bold text-mine">Dashboard</h2>
            <div class="row">
                <div class="col-12 my-4">
                    <div class="posts-panel supervisor-panel p-4 my-4">
                        <h5 class="fw-bold d-flex align-items-center pb-3">
                            Events Requests
                            <div class="panel-icon">
                                <i class="fa-solid fa-calendar"></i>
                            </div>
                        </h5>
                        @if (count($events) < 1)
                            <p class="fw-bold text-center">
                                No Event Request Yet
                            </p>
                        @endif
                        @foreach ($events as $event)
                            <div class="post supervisor-panel-div p-3 text-center my-4">
                                <div class="row pb-3">
                                    <h6 class="fw-bold">
                                        Requested by {{ $event->instructor->full_name }}
                                        {{ \Carbon\Carbon::parse($event->created_at)->format('d/m/Y g:i A') }}
                                    </h6>
                                </div>
                                <div class="post-content py-4">
                                    <h5 class="py-1">
                                        <span class="fw-bold">Event Title: </span>
                                        {{ $event->title }}
                                    </h5>
                                    <h5 class="py-1">
                                        <span class="fw-bold">Event Subject: </span>
                                        {{ $event->subject }}
                                    </h5>
                                    <h5 class="py-1">
                                        <span class="fw-bold">Event Date: </span>
                                        {{ \Carbon\Carbon::parse($event->start_date)->format('d/m/Y g:i A') }}
                                    </h5>
                                    <h5 class="py-1">
                                        <span class="fw-bold">Event Hall: </span>
                                        {{ $event->hall }}
                                    </h5>
                                    <h5 class="fw-bold pt-4 pb-1">Event Description</h5>
                                    <p class="pt-1 pb-4">
                                        {{ $event->desc }}
                                    </p>
                                </div>
                                <div class="row pt-3">
                                    <div class="col-6 text-end">
                                        <a href="{{ route('event.accept', $event->id) }}" class="btn btn-success">
                                            <h6 class="fw-bold">
                                                Accept
                                                <i class="fa-solid fa-check ps-2"></i>
                                            </h6>
                                        </a>
                                    </div>
                                    <div class="col-6 text-start">
                                        <a href="{{ route('event.reject', $event->id) }}" class="btn btn-danger">
                                            <h6 class="fw-bold">
                                                Reject
                                                <i class="fa-solid fa-x"></i>
                                            </h6>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                        <div class="d-flex justify-content-center">
                            {!! $events->links() !!}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
