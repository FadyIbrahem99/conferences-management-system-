@extends('layout')

@section('title')
    Login
@endsection

@section('styles')
    <link rel="stylesheet" href="{{ asset('css/auth/login-type.css') }}">
@endsection

@section('content')
    <section class="pb-5 bg-mine h-100 d-flex align-items-center">
        <div class="container">
            <div class="types-wrapper bg-light mx-auto p-5">
                <h3 class="text-center fw-bold">Login as</h3>
                <div class="hr-mine"></div>
                <div class="row justify-content-center py-5">
                    <div class="col-md-3 p-3">
                        <a href="{{ route('guest.login') }}" class="text-decoration-none">
                            <div class="login-type px-4 py-5 d-flex flex-column align-items-center justify-content-center">
                                <i class="fa-solid fa-graduation-cap"></i>
                                <h4 class="fw-bold pt-4">Guest</h4>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-3 p-3">
                        <a href="{{ route('instructor.login') }}" class="text-decoration-none">
                            <div class="login-type px-4 py-5 d-flex flex-column align-items-center justify-content-center">
                                <i class="fa-solid fa-person-chalkboard"></i>
                                <h4 class="fw-bold pt-4">Instructor</h4>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-3 p-3">
                        <a href="{{ route('supervisor.login') }}" class="text-decoration-none">
                            <div class="login-type px-4 py-5 d-flex flex-column align-items-center justify-content-center">
                                <i class="fa-solid fa-headset"></i>
                                <h4 class="fw-bold pt-4">Supervisor</h4>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-3 p-3">
                        <a href="{{ route('admin.login') }}" class="text-decoration-none">
                            <div class="login-type px-4 py-5 d-flex flex-column align-items-center justify-content-center">
                                <i class="fa-solid fa-user-gear"></i>
                                <h4 class="fw-bold pt-4">Admin</h4>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
