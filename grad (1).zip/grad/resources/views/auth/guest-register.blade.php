@extends('layout')

@section('title')
    Guest Register
@endsection

@section('styles')
    <link rel="stylesheet" href="{{ asset('css/auth/login.css') }}">
@endsection

@section('content')
    <section class="pb-5 bg-mine h-100 d-flex align-items-center">
        <div class="container">
            <div class="login-panel bg-light mx-auto p-5">
                <div class="text-center text-mine pb-4">
                    <i class="fa-solid fa-graduation-cap"></i>
                </div>
                <h3 class="text-center fw-bold">Guest Register</h3>
                <div class="hr-mine"></div>
                <form action="{{ route('guest.register.handle') }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <input type="text" name="full_name" value="{{ old('full_name') }}" class="form-control my-4"
                        placeholder="Enter Full Name *">
                    <input type="email" name="email" value="{{ old('email') }}" class="form-control my-4"
                        placeholder="Enter E-mail *">
                    <input type="password" name="password" class="form-control my-4" placeholder="Enter Password *">
                    <div class="pb-5">
                        <label for="">Upload Profile Photo</label>
                        <input type="file" class="form-control" name="img">
                    </div>
                    <div class="text-center">
                        <input type="submit" value="Register" class="btn-mine-alt px-4 py-2 fw-bold text-decoration-none">
                    </div>
                </form>
            </div>
        </div>
    </section>
@endsection
