@extends('layout')

@section('title')
    Admin Login
@endsection

@section('styles')
    <link rel="stylesheet" href="{{ asset('css/auth/login.css') }}">
@endsection

@section('content')
    <section class="pb-5 bg-mine h-100 d-flex align-items-center">
        <div class="container">
            <div class="login-panel bg-light mx-auto p-5">
                <div class="text-center text-mine pb-4">
                    <i class="fa-solid fa-user-gear"></i>
                </div>
                <h3 class="text-center fw-bold">Admin Login</h3>
                <div class="hr-mine"></div>
                <form action="{{ route('admin.login.handle') }}" method="POST">
                    @csrf
                    <input type="email" name="email" class="form-control my-4" placeholder="Enter Your E-mail">
                    <input type="password" name="password" class="form-control my-4" placeholder="Enter Your Password">
                    <div class="text-center">
                        <input type="submit" value="Login" class="btn-mine-alt px-4 py-2 fw-bold">
                    </div>
                </form>
            </div>
        </div>
    </section>
@endsection
