@extends('layout')

@section('title')
    Instructor Register
@endsection

@section('styles')
    <link rel="stylesheet" href="{{ asset('css/auth/login.css') }}">
@endsection

@section('content')
    <section class="pb-5 bg-mine h-100 d-flex align-items-center">
        <div class="container">
            <div class="login-panel bg-light mx-auto p-5">
                <div class="text-center text-mine pb-4">
                    <i class="fa-solid fa-person-chalkboard"></i>
                </div>
                <h3 class="text-center fw-bold">Instructor Register</h3>
                <div class="hr-mine"></div>
                <form action="{{ route('instructor.register.handle') }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <input type="text" name="full_name" value="{{ old('full_name') }}" class="form-control my-4"
                        placeholder="Enter Full Name *">
                    <input type="email" name="email" value="{{ old('email') }}" class="form-control my-4"
                        placeholder="Enter E-mail *">
                    <input type="password" name="password" class="form-control my-4" placeholder="Enter Password *">
                    <input type="text" name="specialization" class="form-control my-4" placeholder="Enter Specialization *">
                    <input type="text" name="title" class="form-control my-4" placeholder="Enter Your Job Title *">
                    <textarea name="about" class="form-control my-4" placeholder="Enter a Brief About You *" cols="30" rows="10"></textarea>
                    <input type="number" name="students" class="form-control my-4" placeholder="Enter Your Students Number *">
                    <input type="number" name="reviews" class="form-control my-4" placeholder="Enter Your Reviews Number *">
                    <input type="text" name="twitter" class="form-control my-4" placeholder="Enter Your Twitter Profile URL">
                    <input type="text" name="linkedin" class="form-control my-4" placeholder="Enter Your Linkedin Profile URL">
                    <div class="pb-5">
                        <label for="">Upload Profile Photo</label>
                        <input type="file" class="form-control" name="img">
                    </div>
                    <div class="text-center">
                        <input type="submit" value="Register" class="btn-mine-alt px-4 py-2 fw-bold text-decoration-none">
                    </div>
                </form>
            </div>
        </div>
    </section>
@endsection
