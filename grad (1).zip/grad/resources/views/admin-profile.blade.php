@extends('layout')

@section('title')
    Admin Profile
@endsection

@section('styles')
    <link rel="stylesheet" href="{{ asset('css/admin-profile.css') }}">
@endsection

@section('content')
    <section class="admin-profile-wrapper py-5">
        <div class="container">
            <div class="admin-profile bg-light py-5 px-4 shadow-lg">
                <div class="d-flex justify-content-between">
                    <h3 class="fw-bold text-mine">My Profile</h3>
                    <div>
                        <i class="fa-solid fa-address-card"></i>
                    </div>
                </div>
                <hr>
                <h5 class="text-muted fw-bold">Personal Information</h5>
                <form action="{{ route('admins.update') }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <input type="text" name="full_name" class="form-control my-4" placeholder="Full Name" value="{{ $admin->full_name }}">
                    <input type="file" name="img" class="form-control my-4">
                    <input type="submit" class="btn-mine py-2 px-4" value="Update">
                </form>
            </div>
        </div>
    </section>
@endsection
