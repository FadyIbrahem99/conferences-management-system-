@extends('layout')

@section('title')
    Instructors
@endsection

@section('styles')
    <link rel="stylesheet" href="{{ asset('css/instructors.css') }}">
@endsection

@section('content')
    <header class="py-5">
        <div class="container">
            <h2 class="text-mine fw-bold text-center">Instructors</h2>
            @foreach ($instructors as $instructor)
                <div class="instructor py-4">
                    <div class="row align-items-center">
                        <div class="col-md-3 p-4">
                            <img src="{{ asset('uploads/instructors-profile-images') }}/{{ $instructor->img }}"
                                class="instructor-img w-100">
                        </div>
                        <div class="col-md-6 p-4">
                            <h5 class="fw-bold">{{ $instructor->full_name }}</h5>
                            <h6 class="fw-bold text-muted">{{ $instructor->specialization }}</h6>
                            <h6 class="fw-bold">{{ $instructor->email }}</h6>
                        </div>
                        <div class="col-md-3 d-flex align-items-center">
                            <a href="{{ route('instructor.view', $instructor->id) }}"
                                class="text-decoration-none btn-mine px-4 py-2">
                                <h4 class="p-0 m-0">Open CV</h4>
                            </a>
                        </div>
                    </div>
                </div>
            @endforeach
            <div class="d-flex justify-content-center">
                {!! $instructors->links() !!}
            </div>
        </div>
    </header>
@endsection
