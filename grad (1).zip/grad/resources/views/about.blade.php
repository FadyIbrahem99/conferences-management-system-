@extends('layout')

@section('title')
    About Us
@endsection

@section('styles')
    <link rel="stylesheet" href="{{ asset('css/about.css') }}">
@endsection

@section('content')
    <header class="py-5">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6 p-5">
                    <h2 class="fw-bold text-mine">About Us</h2>
                    <p class="lead">
                        An Independent For-Profit Organization Concerned With The Affairs Of The Arab
                        Scientific Community. It Was Established To Work To Support And Strengthen The Arab Scientific
                        Community, And To Enable It To Contribute To A True And Comprehensive Arab Renaissance Project.
                    </p>
                </div>
                <div class="col-md-6 p-5">
                    <img src="{{ asset('images/about-header.png') }}" class="w-100">
                </div>
            </div>
        </div>
    </header>

    <section class="py-5">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-4 p-5 text-center">
                    <img src="{{ asset('images/about-1.png') }}" class="w-100">
                </div>
                <div class="col-md-4 p-5 text-center">
                    <img src="{{ asset('images/about-2.png') }}" class="w-100">
                </div>
                <div class="col-md-4 p-5 text-center">
                    <img src="{{ asset('images/about-3.png') }}" class="w-100">
                </div>
            </div>
        </div>
    </section>
@endsection
