@extends('layout')

@section('title')
    Dr / Negm El Dien Shawky
@endsection

@section('styles')
    <link rel="stylesheet" href="{{ asset('css/instructor-view.css') }}">
@endsection

@section('content')
    <header class="py-5">
        <div class="container">
            <div class="row align-items-center pb-5">
                <div class="col-md-7 text-md-start text-center py-4 py-md-0">
                    <h5 class="text-muted fw-bold">INSTRUCTOR</h5>
                    <h2 class="fw-bold text-mine">{{ $instructor->full_name }}</h2>
                    <h4 class="text-muted fw-bold">{{ $instructor->title }}</h4>
                </div>
                <div class="col-md-5 text-center">
                    <img src="{{ asset('uploads/instructors-profile-images') }}/{{ $instructor->img }}"
                        class="instructor-img">
                </div>
            </div>
            <div class="row align-items-center py-5">
                <div class="col-md-7">
                    <div class="row">
                        <div class="col-6 text-center">
                            <h4 class="text-mine fw-bold">Total Students</h4>
                            <h4 class="fw-bold">{{ $instructor->students }}</h4>
                        </div>
                        <div class="col-6 text-center">
                            <h4 class="text-mine fw-bold">Reviews</h4>
                            <h4 class="fw-bold">{{ $instructor->reviews }}</h4>
                        </div>
                    </div>
                    <h3 class="fw-bold text-mine pt-5 pb-3">About Me</h3>
                    <p class="lead">
                        {{ $instructor->about }}
                    </p>
                    <div class="social-icons d-flex">
                        @if ($instructor->linkedin != null)
                            <a href="{{ $instructor->linkedin }}" target="_blank"
                                class="text-decoration-none text-light social-icon linkedin-icon mx-4 py-2 px-3 rounded-3">
                                <i class="fa-brands fa-linkedin-in"></i>
                            </a>
                        @endif
                        @if ($instructor->twitter != null)
                            <a href="{{ $instructor->twitter }}" target="_blank"
                                class="text-decoration-none text-light social-icon twitter-icon mx-4 py-2 px-3 rounded-3">
                                <i class="fa-brands fa-twitter"></i>
                            </a>
                        @endif
                    </div>
                </div>
                <div class="col-md-5"></div>
            </div>
        </div>
    </header>
@endsection
