@extends('layout')

@section('title')
    Instructor Profile
@endsection

@section('styles')
    <link rel="stylesheet" href="{{ asset('css/instructor-profile.css') }}">
@endsection

@section('content')
    <section class="instructor-profile-wrapper py-5">
        <div class="container">
            <div class="instructor-profile bg-light py-5 px-4 shadow-lg">
                <div class="d-flex justify-content-between">
                    <h3 class="fw-bold text-mine">My Profile</h3>
                    <div>
                        <i class="fa-solid fa-address-card"></i>
                    </div>
                </div>
                <hr>
                <h5 class="text-muted fw-bold">Personal Information</h5>
                <form action="{{ route('instructors.update') }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <input type="text" name="full_name" class="form-control my-4" placeholder="Full Name"
                        value="{{ $instructor->full_name }}">
                    <input type="text" name="specialization" class="form-control my-4" placeholder="Specialization"
                        value="{{ $instructor->specialization }}">
                    <input type="text" name="title" class="form-control my-4" placeholder="Job Title"
                        value="{{ $instructor->title }}">
                    <textarea name="about" class="form-control my-4" cols="30" rows="10"
                        placeholder="About">{{ $instructor->about }}</textarea>
                    <input type="number" name="students" class="form-control my-4" placeholder="Students"
                        value="{{ $instructor->students }}">
                    <input type="number" name="reviews" class="form-control my-4" placeholder="Reviews"
                        value="{{ $instructor->reviews }}">
                    <input type="text" name="twitter" class="form-control my-4" placeholder="Twitter URL"
                        value="{{ $instructor->twitter }}">
                    <input type="text" name="linkedin" class="form-control my-4" placeholder="Linkedin URL"
                        value="{{ $instructor->linkedin }}">
                    <input type="file" name="img" class="form-control my-4">
                    <input type="submit" class="btn-mine py-2 px-4" value="Update">
                </form>
                <div class="d-flex justify-content-between pt-5">
                    <h3 class="fw-bold text-mine">Requested Events</h3>
                    <div>
                        <a href="{{ route('instructor.request') }}" class="text-decoration-none">
                            <i class="fa-solid fa-plus"></i>
                        </a>
                    </div>
                </div>
                <hr>
            </div>
        </div>
    </section>
@endsection
