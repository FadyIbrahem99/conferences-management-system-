@extends('layout')

@section('title')
    MOATMRKO
@endsection

@section('styles')
    <link rel="stylesheet" href="{{ asset('css/home.css') }}">
@endsection

@section('content')
    <header></header>

    <section class="featured-events py-5 px-4">
        <h3 class="h3 fw-bold text-mine text-center">Featured Events</h3>
        <div class="row p-0 m-0 justify-content-center align-items-center">
            @foreach ($data['events'] as $event)
                <div class="col-md-4 p-5">
                    <div class="featured-event rounded-3 bg-grey border-mine p-4">
                        <div class="featured-event-img pb-5 d-flex justify-content-center align-items-center">
                            <img src="{{ asset('uploads/instructors-profile-images') }}/{{ $event->instructor->img }}">
                        </div>
                        <div class="featured-event-text pt-5 text-center text-mine">
                            <div class="featured-event-date py-2 px-3 bg-mine text-light">
                                <h6 class="fw-bold">{{ \Carbon\Carbon::parse($event->start_date)->format('d') }}</h6>
                                <h6 class="fw-bold">{{ substr(\Carbon\Carbon::parse($event->start_date)->format('F'), 0, 3) }}</h6>
                            </div>
                            <a href="{{ route('instructor.view') }}" class="text-mine text-decoration-none">
                                <h4 class="fw-bold">{{ $event->instructor->full_name }}</h4>
                            </a>
                            <h4>{{ $event->subject }}</h4>
                            <h5>{{ \Carbon\Carbon::parse($event->start_date)->format('g:i A') }} : {{ \Carbon\Carbon::parse($event->end_date)->format('g:i A') }}</h5>
                            <h5 class="pb-4">{{ $event->hall }}</h5>
                            <!--<a href="" class="text-decoration-none btn-mine-alt px-4 py-2">Learn More</a>-->
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
        <div class="text-center">
            <a href="{{ route('events') }}" class="text-decoration-none btn-mine py-2 px-4">More Events</a>
        </div>
    </section>

    @if (count($data['posts']) > 0)
        <section class="posts py-5">
            <div class="container">
                <h2 class="fw-bold text-center text-mine">Posts</h2>
                @foreach ($data['posts'] as $post)
                    <div class="row p-4">
                        <div class="post p-3">
                            <div class="row">
                                <div class="col-6">
                                    <h6 class="fw-bold">{{ $post->admin->full_name }}</h6>
                                </div>
                                <div class="col-6 text-end">
                                    <h6 class="fw-bold">
                                        {{ \Carbon\Carbon::parse($post->created_at)->format('d/m/Y g:i A') }}
                                    </h6>
                                </div>
                            </div>
                            <div class="row py-5 text-center">
                                <p class="fw-bold">
                                    {{ $post->content }}
                                </p>
                            </div>
                            <!--<a href="" class="text-light text-decoration-none fw-bold p-3 liked">
                                Like
                                <i class="fa-solid fa-thumbs-up ps-2"></i>
                            </a>-->
                        </div>
                    </div>
                @endforeach
                <div class="d-flex justify-content-center">
                    {!! $data['posts']->links() !!}
                </div>
            </div>
        </section>
    @endif
@endsection
