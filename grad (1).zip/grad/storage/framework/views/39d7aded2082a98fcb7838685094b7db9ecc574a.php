

<?php $__env->startSection('title'); ?>
    Dr / Negm El Dien Shawky
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/instructor-view.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <header class="py-5">
        <div class="container">
            <div class="row align-items-center pb-5">
                <div class="col-md-7 text-md-start text-center py-4 py-md-0">
                    <h5 class="text-muted fw-bold">INSTRUCTOR</h5>
                    <h2 class="fw-bold text-mine"><?php echo e($instructor->full_name); ?></h2>
                    <h4 class="text-muted fw-bold"><?php echo e($instructor->title); ?></h4>
                </div>
                <div class="col-md-5 text-center">
                    <img src="<?php echo e(asset('uploads/instructors-profile-images')); ?>/<?php echo e($instructor->img); ?>"
                        class="instructor-img">
                </div>
            </div>
            <div class="row align-items-center py-5">
                <div class="col-md-7">
                    <div class="row">
                        <div class="col-6 text-center">
                            <h4 class="text-mine fw-bold">Total Students</h4>
                            <h4 class="fw-bold"><?php echo e($instructor->students); ?></h4>
                        </div>
                        <div class="col-6 text-center">
                            <h4 class="text-mine fw-bold">Reviews</h4>
                            <h4 class="fw-bold"><?php echo e($instructor->reviews); ?></h4>
                        </div>
                    </div>
                    <h3 class="fw-bold text-mine pt-5 pb-3">About Me</h3>
                    <p class="lead">
                        <?php echo e($instructor->about); ?>

                    </p>
                    <div class="social-icons d-flex">
                        <?php if($instructor->linkedin != null): ?>
                            <a href="<?php echo e($instructor->linkedin); ?>" target="_blank"
                                class="text-decoration-none text-light social-icon linkedin-icon mx-4 py-2 px-3 rounded-3">
                                <i class="fa-brands fa-linkedin-in"></i>
                            </a>
                        <?php endif; ?>
                        <?php if($instructor->twitter != null): ?>
                            <a href="<?php echo e($instructor->twitter); ?>" target="_blank"
                                class="text-decoration-none text-light social-icon twitter-icon mx-4 py-2 px-3 rounded-3">
                                <i class="fa-brands fa-twitter"></i>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-md-5"></div>
            </div>
        </div>
    </header>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\grad\resources\views/instructor-view.blade.php ENDPATH**/ ?>