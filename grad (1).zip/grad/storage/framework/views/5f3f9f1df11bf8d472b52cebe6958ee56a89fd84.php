

<?php $__env->startSection('title'); ?>
    Admin Register
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/auth/login.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="pb-5 bg-mine h-100 d-flex align-items-center">
        <div class="container">
            <div class="login-panel bg-light mx-auto p-5">
                <div class="text-center text-mine pb-4">
                    <i class="fa-solid fa-user-gear"></i>
                </div>
                <h3 class="text-center fw-bold">Admin Register</h3>
                <div class="hr-mine"></div>
                <form action="<?php echo e(route('admin.register.handle')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="text" name="full_name" value="<?php echo e(old('full_name')); ?>" class="form-control my-4"
                        placeholder="Enter Full Name *">
                    <input type="email" name="email" value="<?php echo e(old('email')); ?>" class="form-control my-4"
                        placeholder="Enter E-mail *">
                    <input type="password" name="password" class="form-control my-4" placeholder="Enter Password *">
                    <div class="pb-5">
                        <label for="">Upload Profile Photo</label>
                        <input type="file" class="form-control" name="img">
                    </div>
                    <div class="text-center">
                        <input type="submit" value="Register" class="btn-mine-alt px-4 py-2 fw-bold text-decoration-none">
                    </div>
                </form>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\grad\resources\views/auth/admin-register.blade.php ENDPATH**/ ?>