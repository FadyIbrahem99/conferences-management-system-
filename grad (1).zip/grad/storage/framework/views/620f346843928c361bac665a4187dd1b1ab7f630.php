<?php $__env->startSection('title'); ?>
    Events
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/events.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <header>
        <div class="container">
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row align-items-center fst-italic py-2">
                    <div class="col-2 event-date text-center bg-beig d-inline-block">
                        <h3 class="fw-bold"><?php echo e(\Carbon\Carbon::parse($event->start_date)->format('d')); ?></h3>
                        <h5><?php echo e(substr(\Carbon\Carbon::parse($event->start_date)->format('F'), 0, 3)); ?></h5>
                    </div>
                    <div class="col-10 event-text p-4">
                        <h6 class="fw-bold"><?php echo e($event->title); ?></h6>
                        <h6><?php echo e($event->subject); ?> | <?php echo e(\Carbon\Carbon::parse($event->start_date)->format('g:i A')); ?></h6>
                        <h6><?php echo e($event->instructor->full_name); ?></h6>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </header>

    <section class="py-5">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-6 col-md-3 p-5 text-center">
                    <img src="<?php echo e(asset('images/events-1.png')); ?>" class="w-100">
                </div>
                <div class="col-6 col-md-3 p-5 text-center">
                    <img src="<?php echo e(asset('images/events-2.png')); ?>" class="w-100">
                </div>
                <div class="col-6 col-md-3 p-5 text-center">
                    <img src="<?php echo e(asset('images/events-3.png')); ?>" class="w-100">
                </div>
                <div class="col-6 col-md-3 p-5 text-center">
                    <img src="<?php echo e(asset('images/events-4.png')); ?>" class="w-100">
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\grad\resources\views/events.blade.php ENDPATH**/ ?>