<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;700&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/57722b608e.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="<?php echo e(asset('css/trix.css')); ?>">
    <script src="<?php echo e(asset('js/trix.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset('css/supervisor-dashboard/supervisor-dashboard-layout.css')); ?>">
    <?php echo $__env->yieldContent('styles'); ?>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-mine">
        <div class="container-fluid">
            <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
                <img src="<?php echo e(asset('images/nav-logo.png')); ?>">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link text-light" href="<?php echo e(route('home')); ?>">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-light" href="<?php echo e(route('events')); ?>">Events</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-light" href="<?php echo e(route('instructors')); ?>">Instructors</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-light" href="<?php echo e(route('lectures')); ?>">Lectures</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-light" href="<?php echo e(route('about')); ?>">About Us</a>
                    </li>
                </ul>
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <?php if(Auth::guard('admin')->user()): ?>
                        <li class="nav-item profile-item">
                            <a class="nav-link text-light mx-3" href="<?php echo e(route('admins.profile')); ?>">
                                <img src="<?php echo e(asset('uploads/admins-profile-images')); ?>/<?php echo e(Auth::guard('admin')->user()->img); ?>"
                                    class="profile-img me-2">
                                <?php echo e(Auth::guard('admin')->user()->full_name); ?>

                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-light" href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-light" href="<?php echo e(route('admin.logout')); ?>">Logout</a>
                        </li>
                    <?php endif; ?>
                    <?php if(Auth::guard('supervisor')->user()): ?>
                        <li class="nav-item profile-item">
                            <a class="nav-link text-light mx-3" href="<?php echo e(route('supervisors.profile')); ?>">
                                <img src="<?php echo e(asset('uploads/supervisors-profile-images')); ?>/<?php echo e(Auth::guard('supervisor')->user()->img); ?>"
                                    class="profile-img me-2">
                                <?php echo e(Auth::guard('supervisor')->user()->full_name); ?>

                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-light" href="<?php echo e(route('supervisor.dashboard')); ?>">Dashboard</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-light" href="<?php echo e(route('supervisor.logout')); ?>">Logout</a>
                        </li>
                    <?php endif; ?>
                    <?php if(Auth::guard('guest')->user()): ?>
                        <li class="nav-item profile-item">
                            <a class="nav-link text-light mx-3" href="<?php echo e(route('guests.profile')); ?>">
                                <img src="<?php echo e(asset('uploads/guests-profile-images')); ?>/<?php echo e(Auth::guard('guest')->user()->img); ?>"
                                    class="profile-img me-2">
                                <?php echo e(Auth::guard('guest')->user()->full_name); ?>

                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-light" href="<?php echo e(route('guest.logout')); ?>">Logout</a>
                        </li>
                    <?php endif; ?>
                    <?php if(Auth::guard('instructor')->user()): ?>
                        <li class="nav-item profile-item">
                            <a class="nav-link text-light mx-3" href="<?php echo e(route('instructors.profile')); ?>">
                                <img src="<?php echo e(asset('uploads/instructors-profile-images')); ?>/<?php echo e(Auth::guard('instructor')->user()->img); ?>"
                                    class="profile-img me-2">
                                <?php echo e(Auth::guard('instructor')->user()->full_name); ?>

                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-light" href="<?php echo e(route('instructor.logout')); ?>">Logout</a>
                        </li>
                    <?php endif; ?>
                    <?php if(!Auth::guard('admin')->user() && !Auth::guard('supervisor')->user() && !Auth::guard('guest')->user() && !Auth::guard('instructor')->user()): ?>
                        <li class="nav-item">
                            <a class="nav-link text-light" href="<?php echo e(route('login')); ?>">Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-light" href="<?php echo e(route('register')); ?>">Register</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <?php echo $__env->yieldContent('content'); ?>

    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery-3.6.0.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\grad\resources\views/supervisor-dashboard/supervisor-dashboard-layout.blade.php ENDPATH**/ ?>