<?php $__env->startSection('title'); ?>
    MOATMRKO
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/home.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <header></header>

    <section class="featured-events py-5 px-4">
        <h3 class="h3 fw-bold text-mine text-center">Featured Events</h3>
        <div class="row p-0 m-0 justify-content-center align-items-center">
            <?php $__currentLoopData = $data['events']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 p-5">
                    <div class="featured-event rounded-3 bg-grey border-mine p-4">
                        <div class="featured-event-img pb-5 d-flex justify-content-center align-items-center">
                            <img src="<?php echo e(asset('uploads/instructors-profile-images')); ?>/<?php echo e($event->instructor->img); ?>">
                        </div>
                        <div class="featured-event-text pt-5 text-center text-mine">
                            <div class="featured-event-date py-2 px-3 bg-mine text-light">
                                <h6 class="fw-bold"><?php echo e(\Carbon\Carbon::parse($event->start_date)->format('d')); ?></h6>
                                <h6 class="fw-bold"><?php echo e(substr(\Carbon\Carbon::parse($event->start_date)->format('F'), 0, 3)); ?></h6>
                            </div>
                            <a href="<?php echo e(route('instructor.view')); ?>" class="text-mine text-decoration-none">
                                <h4 class="fw-bold"><?php echo e($event->instructor->full_name); ?></h4>
                            </a>
                            <h4><?php echo e($event->subject); ?></h4>
                            <h5><?php echo e(\Carbon\Carbon::parse($event->start_date)->format('g:i A')); ?> : <?php echo e(\Carbon\Carbon::parse($event->end_date)->format('g:i A')); ?></h5>
                            <h5 class="pb-4"><?php echo e($event->hall); ?></h5>
                            <!--<a href="" class="text-decoration-none btn-mine-alt px-4 py-2">Learn More</a>-->
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="text-center">
            <a href="<?php echo e(route('events')); ?>" class="text-decoration-none btn-mine py-2 px-4">More Events</a>
        </div>
    </section>

    <?php if(count($data['posts']) > 0): ?>
        <section class="posts py-5">
            <div class="container">
                <h2 class="fw-bold text-center text-mine">Posts</h2>
                <?php $__currentLoopData = $data['posts']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row p-4">
                        <div class="post p-3">
                            <div class="row">
                                <div class="col-6">
                                    <h6 class="fw-bold"><?php echo e($post->admin->full_name); ?></h6>
                                </div>
                                <div class="col-6 text-end">
                                    <h6 class="fw-bold">
                                        <?php echo e(\Carbon\Carbon::parse($post->created_at)->format('d/m/Y g:i A')); ?>

                                    </h6>
                                </div>
                            </div>
                            <div class="row py-5 text-center">
                                <p class="fw-bold">
                                    <?php echo e($post->content); ?>

                                </p>
                            </div>
                            <!--<a href="" class="text-light text-decoration-none fw-bold p-3 liked">
                                Like
                                <i class="fa-solid fa-thumbs-up ps-2"></i>
                            </a>-->
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="d-flex justify-content-center">
                    <?php echo $data['posts']->links(); ?>

                </div>
            </div>
        </section>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\grad\resources\views/home.blade.php ENDPATH**/ ?>