

<?php $__env->startSection('title'); ?>
    Supervisor Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/supervisor-dashboard/supervisor-dashboard.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <header></header>
    <section class="featured-events py-5 px-4">
        <div class="container-fluid">
            <h2 class="fw-bold text-mine">Dashboard</h2>
            <div class="row">
                <div class="col-12 my-4">
                    <div class="posts-panel supervisor-panel p-4 my-4">
                        <h5 class="fw-bold d-flex align-items-center pb-3">
                            Events Requests
                            <div class="panel-icon">
                                <i class="fa-solid fa-calendar"></i>
                            </div>
                        </h5>
                        <?php if(count($events) < 1): ?>
                            <p class="fw-bold text-center">
                                No Event Request Yet
                            </p>
                        <?php endif; ?>
                        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="post supervisor-panel-div p-3 text-center my-4">
                                <div class="row pb-3">
                                    <h6 class="fw-bold">
                                        Requested by <?php echo e($event->instructor->full_name); ?>

                                        <?php echo e(\Carbon\Carbon::parse($event->created_at)->format('d/m/Y g:i A')); ?>

                                    </h6>
                                </div>
                                <div class="post-content py-4">
                                    <h5 class="py-1">
                                        <span class="fw-bold">Event Title: </span>
                                        <?php echo e($event->title); ?>

                                    </h5>
                                    <h5 class="py-1">
                                        <span class="fw-bold">Event Subject: </span>
                                        <?php echo e($event->subject); ?>

                                    </h5>
                                    <h5 class="py-1">
                                        <span class="fw-bold">Event Date: </span>
                                        <?php echo e(\Carbon\Carbon::parse($event->start_date)->format('d/m/Y g:i A')); ?>

                                    </h5>
                                    <h5 class="py-1">
                                        <span class="fw-bold">Event Hall: </span>
                                        <?php echo e($event->hall); ?>

                                    </h5>
                                    <h5 class="fw-bold pt-4 pb-1">Event Description</h5>
                                    <p class="pt-1 pb-4">
                                        <?php echo e($event->desc); ?>

                                    </p>
                                </div>
                                <div class="row pt-3">
                                    <div class="col-6 text-end">
                                        <a href="<?php echo e(route('event.accept', $event->id)); ?>" class="btn btn-success">
                                            <h6 class="fw-bold">
                                                Accept
                                                <i class="fa-solid fa-check ps-2"></i>
                                            </h6>
                                        </a>
                                    </div>
                                    <div class="col-6 text-start">
                                        <a href="<?php echo e(route('event.reject', $event->id)); ?>" class="btn btn-danger">
                                            <h6 class="fw-bold">
                                                Reject
                                                <i class="fa-solid fa-x"></i>
                                            </h6>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex justify-content-center">
                            <?php echo $events->links(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('supervisor-dashboard/supervisor-dashboard-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\grad\resources\views/supervisor-dashboard/supervisor-dashboard.blade.php ENDPATH**/ ?>