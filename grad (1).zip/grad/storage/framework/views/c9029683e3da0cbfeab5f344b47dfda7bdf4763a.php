

<?php $__env->startSection('title'); ?>
    Admin Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/admin-dashboard/admin-dashboard.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <header></header>
    <section class="featured-events py-5 px-4">
        <div class="container-fluid">
            <h2 class="fw-bold text-mine">Dashboard</h2>
            <div class="row">
                <div class="col-md-4 my-4">
                    <div class="insights-panel admin-panel p-4">
                        <h5 class="fw-bold d-flex align-items-center">
                            Insights
                            <div class="panel-icon">
                                <i class="fa-solid fa-chart-line"></i>
                            </div>
                        </h5>
                        <div class="row">
                            <div class="col-md-6 p-3">
                                <div class="admin-panel-div p-3 text-center">
                                    <div class="panel-icon mx-auto">
                                        <i class="fa-solid fa-calendar"></i>
                                    </div>
                                    <h6 class="fw-bold py-3">Events</h6>
                                    <h5 class="fw-bold"><?php echo e($data['events_count']); ?></h5>
                                </div>
                            </div>
                            <!--<div class="col-md-6 p-3">
                                <div class="admin-panel-div p-3 text-center">
                                    <div class="panel-icon mx-auto">
                                        <i class="fa-solid fa-people-group"></i>
                                    </div>
                                    <h6 class="fw-bold py-3">People Reached</h6>
                                    <h5 class="fw-bold">29</h5>
                                </div>
                            </div>-->
                            <div class="col-md-6 p-3">
                                <div class="admin-panel-div p-3 text-center">
                                    <div class="panel-icon mx-auto">
                                        <i class="fa-solid fa-file-lines"></i>
                                    </div>
                                    <h6 class="fw-bold py-3">Posts</h6>
                                    <h5 class="fw-bold"><?php echo e($data['posts_count']); ?></h5>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 p-3">
                                <div class="admin-panel-div p-3 text-center">
                                    <div class="panel-icon mx-auto">
                                        <i class="fa-solid fa-user-gear"></i>
                                    </div>
                                    <h6 class="fw-bold py-3">Admins</h6>
                                    <h5 class="fw-bold"><?php echo e($data['admins_count']); ?></h5>
                                </div>
                            </div>
                            <div class="col-md-6 p-3">
                                <div class="admin-panel-div p-3 text-center">
                                    <div class="panel-icon mx-auto">
                                        <i class="fa-solid fa-headset"></i>
                                    </div>
                                    <h6 class="fw-bold py-3">Supervisors</h6>
                                    <h5 class="fw-bold"><?php echo e($data['supervisors_count']); ?></h5>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 p-3">
                                <div class="admin-panel-div p-3 text-center">
                                    <div class="panel-icon mx-auto">
                                        <i class="fa-solid fa-graduation-cap"></i>
                                    </div>
                                    <h6 class="fw-bold py-3">Guests</h6>
                                    <h5 class="fw-bold"><?php echo e($data['guests_count']); ?></h5>
                                </div>
                            </div>
                            <div class="col-md-6 p-3">
                                <div class="admin-panel-div p-3 text-center">
                                    <div class="panel-icon mx-auto">
                                        <i class="fa-solid fa-person-chalkboard"></i>
                                    </div>
                                    <h6 class="fw-bold py-3">Instructors</h6>
                                    <h5 class="fw-bold"><?php echo e($data['instructors_count']); ?></h5>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <!--<div class="col-md-6 p-3">
                                <div class="admin-panel-div p-3 text-center">
                                    <div class="panel-icon mx-auto">
                                        <i class="fa-solid fa-video"></i>
                                    </div>
                                    <h6 class="fw-bold py-3">Lectures</h6>
                                    <h5 class="fw-bold">36</h5>
                                </div>
                            </div>-->
                        </div>
                        <div class="row">
                            <div class="col-12 p-3">
                                <div class="admin-panel-div p-3 text-start">
                                    <div class="d-flex justify-content-between">
                                        <h6 class="fw-bold d-flex align-items-center">
                                            Admins
                                            <div class="panel-icon">
                                                <i class="fa-solid fa-user-gear"></i>
                                            </div>
                                        </h6>
                                        <a href="<?php echo e(route('admin.register')); ?>" class="text-decoration-none">
                                            <div class="panel-icon">
                                                <i class="fa-solid fa-plus"></i>
                                            </div>
                                        </a>
                                    </div>
                                    <?php $__currentLoopData = $data['admins']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="d-flex py-4 justify-content-between align-items-center">
                                            <h6 class="fw-bold"><?php echo e($admin->full_name); ?></h6>
                                            <div>
                                                <a href="<?php echo e(route('admins.delete', $admin->id)); ?>"
                                                    class="text-decoration-none text-light p-2">
                                                    <i class="fa-solid fa-trash"></i>
                                                </a>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <div class="d-flex justify-content-center">
                                        <?php echo $data['admins']->links(); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12 p-3">
                                <div class="admin-panel-div p-3 text-start">
                                    <div class="d-flex justify-content-between">
                                        <h6 class="fw-bold d-flex align-items-center">
                                            Supervisors
                                            <div class="panel-icon">
                                                <i class="fa-solid fa-headset"></i>
                                            </div>
                                        </h6>
                                        <a href="<?php echo e(route('supervisor.register')); ?>" class="text-decoration-none">
                                            <div class="panel-icon">
                                                <i class="fa-solid fa-plus"></i>
                                            </div>
                                        </a>
                                    </div>
                                    <?php $__currentLoopData = $data['supervisors']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supervisor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="d-flex py-4 justify-content-between align-items-center">
                                            <h6 class="fw-bold"><?php echo e($supervisor->full_name); ?></h6>
                                            <div>
                                                <a href="<?php echo e(route('supervisors.delete', $supervisor->id)); ?>"
                                                    class="text-decoration-none text-light p-2">
                                                    <i class="fa-solid fa-trash"></i>
                                                </a>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <div class="d-flex justify-content-center">
                                        <?php echo $data['supervisors']->links(); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12 p-3">
                                <div class="admin-panel-div p-3 text-start">
                                    <div class="d-flex justify-content-between">
                                        <h6 class="fw-bold d-flex align-items-center">
                                            Guests
                                            <div class="panel-icon">
                                                <i class="fa-solid fa-graduation-cap"></i>
                                            </div>
                                        </h6>
                                        <a href="<?php echo e(route('guest.register')); ?>" class="text-decoration-none">
                                            <div class="panel-icon">
                                                <i class="fa-solid fa-plus"></i>
                                            </div>
                                        </a>
                                    </div>
                                    <?php $__currentLoopData = $data['guests']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="d-flex py-4 justify-content-between align-items-center">
                                            <h6 class="fw-bold"><?php echo e($guest->full_name); ?></h6>
                                            <div>
                                                <a href="<?php echo e(route('guests.delete', $guest->id)); ?>"
                                                    class="text-decoration-none text-light p-2">
                                                    <i class="fa-solid fa-trash"></i>
                                                </a>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <div class="d-flex justify-content-center">
                                        <?php echo $data['guests']->links(); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12 p-3">
                                <div class="admin-panel-div p-3 text-start">
                                    <div class="d-flex justify-content-between">
                                        <h6 class="fw-bold d-flex align-items-center">
                                            Instructors
                                            <div class="panel-icon">
                                                <i class="fa-solid fa-person-chalkboard"></i>
                                            </div>
                                        </h6>
                                        <a href="<?php echo e(route('instructor.register')); ?>" class="text-decoration-none">
                                            <div class="panel-icon">
                                                <i class="fa-solid fa-plus"></i>
                                            </div>
                                        </a>
                                    </div>
                                    <?php $__currentLoopData = $data['instructors']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instructor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="d-flex py-4 justify-content-between align-items-center">
                                            <h6 class="fw-bold"><?php echo e($instructor->full_name); ?></h6>
                                            <div>
                                                <a href="<?php echo e(route('instructors.delete', $instructor->id)); ?>"
                                                    class="text-decoration-none text-light p-2">
                                                    <i class="fa-solid fa-trash"></i>
                                                </a>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <div class="d-flex justify-content-center">
                                        <?php echo $data['instructors']->links(); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-8 my-4">
                    <div class="create-post-panel admin-panel p-4">
                        <h5 class="fw-bold d-flex align-items-center pb-3">
                            Create Post
                            <div class="panel-icon">
                                <i class="fa-solid fa-plus"></i>
                            </div>
                        </h5>
                        <form action="<?php echo e(route('posts.publish')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <label class="pb-3">Post Content</label>
                            <textarea name="content" class="form-control bg-transparent text-light" cols="30" rows="10"></textarea>
                            <div class="text-center pt-4">
                                <input type="submit" value="Publish"
                                    class="text-decoration-none border-0 panel-btn py-2 px-4 rounded-pill">
                            </div>
                        </form>
                    </div>
                    <div class="posts-panel admin-panel p-4 my-4">
                        <h5 class="fw-bold d-flex align-items-center pb-3">
                            Posts
                            <div class="panel-icon">
                                <i class="fa-solid fa-file-lines"></i>
                            </div>
                        </h5>
                        <?php $__currentLoopData = $data['posts']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="post admin-panel-div p-3 text-center my-4">
                                <div class="row pb-3">
                                    <div class="col-6 text-start">
                                        <h6 class="fw-bold">Published by <?php echo e($post->admin->full_name); ?>

                                            <?php echo e(\Carbon\Carbon::parse($post->created_at)->format('d/m/Y g:i A')); ?></h6>
                                    </div>
                                    <div class="col-6 text-end">
                                        <a href="<?php echo e(route('posts.delete', $post->id)); ?>"
                                            class="text-decoration-none text-light p-2">
                                            <i class="fa-solid fa-trash"></i>
                                        </a>
                                    </div>
                                </div>
                                <div class="post-content py-4">
                                    <p>
                                        <?php echo e($post->content); ?>

                                    </p>
                                </div>
                                <!--<div class="row pt-3">
                                    <div class="col-6 text-center">
                                        <h6 class="fw-bold">People Reached: <?php echo e($post->views); ?></h6>
                                    </div>
                                    <div class="col-6 text-center">
                                        <h6 class="fw-bold">Likes: <?php echo e($post->likes); ?></h6>
                                    </div>
                                </div>-->
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex justify-content-center">
                            <?php echo $data['posts']->links(); ?>

                        </div>
                    </div>
                    <div class="posts-panel admin-panel p-4 my-4">
                        <h5 class="fw-bold d-flex align-items-center pb-3">
                            Events
                            <div class="panel-icon">
                                <i class="fa-solid fa-calendar"></i>
                            </div>
                        </h5>
                        <?php $__currentLoopData = $data['events']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="post admin-panel-div p-3 text-center my-4">
                                <div class="row pb-3 text-end">
                                    <a href="<?php echo e(route('events.delete', $event->id)); ?>"
                                        class="text-decoration-none text-light p-2">
                                        <i class="fa-solid fa-trash"></i>
                                    </a>
                                </div>
                                <div class="post-content py-4">
                                    <h5 class="fw-bold"><?php echo e($event->title); ?></h5>
                                    <h4 class="fw-bold"><?php echo e($event->subject); ?></h4>
                                    <h6 class="fw-bold">
                                        <?php echo e(\Carbon\Carbon::parse($event->start_date)->format('d/m/Y g:i A')); ?></h6>
                                    <p>
                                        <?php echo e($event->desc); ?>

                                    </p>
                                    <h6 class="fw-bold"><?php echo e($event->hall); ?></h6>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex justify-content-center">
                            <?php echo $data['events']->links(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin-dashboard/admin-dashboard-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\grad\resources\views/admin-dashboard/admin-dashboard.blade.php ENDPATH**/ ?>