<?php $__env->startSection('title'); ?>
    Lectures
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/lectures.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <header class="py-5">
        <div class="container">
            <div class="row justify-content-center">
                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(Carbon\Carbon::now() > $event->end_date): ?>
                        <div class="col-md-6 p-4 my-4">
                            <h4 class="text-center fw-bold text-mine"><?php echo e($event->title); ?></h4>
                            <h6 class="text-center fw-bold text-muted"><?php echo e($event->instructor->full_name); ?></h6>
                            <iframe class="w-100" height="315" src="<?php echo e($event->video); ?>"
                                title="YouTube video player" frameborder="0"
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                allowfullscreen></iframe>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </header>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\grad\resources\views/lectures.blade.php ENDPATH**/ ?>