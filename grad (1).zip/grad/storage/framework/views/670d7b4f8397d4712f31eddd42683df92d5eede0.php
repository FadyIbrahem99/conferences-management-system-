

<?php $__env->startSection('title'); ?>
    Instructor Profile
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/instructor-profile.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="instructor-profile-wrapper py-5">
        <div class="container">
            <div class="instructor-profile bg-light py-5 px-4 shadow-lg">
                <div class="d-flex justify-content-between">
                    <h3 class="fw-bold text-mine">My Profile</h3>
                    <div>
                        <i class="fa-solid fa-address-card"></i>
                    </div>
                </div>
                <hr>
                <h5 class="text-muted fw-bold">Personal Information</h5>
                <form action="<?php echo e(route('instructors.update')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="text" name="full_name" class="form-control my-4" placeholder="Full Name"
                        value="<?php echo e($instructor->full_name); ?>">
                    <input type="text" name="specialization" class="form-control my-4" placeholder="Specialization"
                        value="<?php echo e($instructor->specialization); ?>">
                    <input type="text" name="title" class="form-control my-4" placeholder="Job Title"
                        value="<?php echo e($instructor->title); ?>">
                    <textarea name="about" class="form-control my-4" cols="30" rows="10"
                        placeholder="About"><?php echo e($instructor->about); ?></textarea>
                    <input type="number" name="students" class="form-control my-4" placeholder="Students"
                        value="<?php echo e($instructor->students); ?>">
                    <input type="number" name="reviews" class="form-control my-4" placeholder="Reviews"
                        value="<?php echo e($instructor->reviews); ?>">
                    <input type="text" name="twitter" class="form-control my-4" placeholder="Twitter URL"
                        value="<?php echo e($instructor->twitter); ?>">
                    <input type="text" name="linkedin" class="form-control my-4" placeholder="Linkedin URL"
                        value="<?php echo e($instructor->linkedin); ?>">
                    <input type="file" name="img" class="form-control my-4">
                    <input type="submit" class="btn-mine py-2 px-4" value="Update">
                </form>
                <div class="d-flex justify-content-between pt-5">
                    <h3 class="fw-bold text-mine">Requested Events</h3>
                    <div>
                        <a href="<?php echo e(route('instructor.request')); ?>" class="text-decoration-none">
                            <i class="fa-solid fa-plus"></i>
                        </a>
                    </div>
                </div>
                <hr>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\grad\resources\views/instructor-profile.blade.php ENDPATH**/ ?>