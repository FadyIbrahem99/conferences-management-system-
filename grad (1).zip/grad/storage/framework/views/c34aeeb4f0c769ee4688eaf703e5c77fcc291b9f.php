<?php $__env->startSection('title'); ?>
    Instructors
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/instructors.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <header class="py-5">
        <div class="container">
            <h2 class="text-mine fw-bold text-center">Instructors</h2>
            <?php $__currentLoopData = $instructors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instructor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="instructor py-4">
                    <div class="row align-items-center">
                        <div class="col-md-3 p-4">
                            <img src="<?php echo e(asset('uploads/instructors-profile-images')); ?>/<?php echo e($instructor->img); ?>"
                                class="instructor-img w-100">
                        </div>
                        <div class="col-md-6 p-4">
                            <h5 class="fw-bold"><?php echo e($instructor->full_name); ?></h5>
                            <h6 class="fw-bold text-muted"><?php echo e($instructor->specialization); ?></h6>
                            <h6 class="fw-bold"><?php echo e($instructor->email); ?></h6>
                        </div>
                        <div class="col-md-3 d-flex align-items-center">
                            <a href="<?php echo e(route('instructor.view', $instructor->id)); ?>"
                                class="text-decoration-none btn-mine px-4 py-2">
                                <h4 class="p-0 m-0">Open CV</h4>
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="d-flex justify-content-center">
                <?php echo $instructors->links(); ?>

            </div>
        </div>
    </header>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\grad\resources\views/instructors.blade.php ENDPATH**/ ?>