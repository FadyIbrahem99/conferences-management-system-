

<?php $__env->startSection('title'); ?>
    Guest Profile
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/guest-profile.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="guest-profile-wrapper py-5">
        <div class="container">
            <div class="guest-profile bg-light py-5 px-4 shadow-lg">
                <div class="d-flex justify-content-between">
                    <h3 class="fw-bold text-mine">My Profile</h3>
                    <div>
                        <i class="fa-solid fa-address-card"></i>
                    </div>
                </div>
                <hr>
                <h5 class="text-muted fw-bold">Personal Information</h5>
                <form action="<?php echo e(route('guests.update')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="text" name="full_name" class="form-control my-4" placeholder="Full Name" value="<?php echo e($guest->full_name); ?>">
                    <input type="file" name="img" class="form-control my-4">
                    <input type="submit" class="btn-mine py-2 px-4" value="Update">
                </form>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\grad\resources\views/guest-profile.blade.php ENDPATH**/ ?>